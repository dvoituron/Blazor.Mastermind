using System;
using Microsoft.AspNetCore.Blazor.Components;

namespace $rootnamespace$
{
    public class $safeitemname$Model : BlazorComponent
    {
        protected override void OnInit()
        {
        }

        protected override void OnAfterRender()
        {
        }
    }
}