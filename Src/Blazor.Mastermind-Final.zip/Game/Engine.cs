﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Blazor.Mastermind.Game
{
    public class Engine
    {
        public static string NO_COLOR = "white";
        public static string[] COLORS_PALETTE = new[] { "red", "blue", "green", "orange", "black" };

        public Engine()
        {
            Start();
        }

        public Row ComputerChoice { get; set; } = new Row();

        public List<Row> Rows { get; set; } = new List<Row>();

        public void Start()
        {
            for (int i = 0; i < 4; i++)
            {
                ComputerChoice.Colors[i] = COLORS_PALETTE[i];
            }

            Rows.Clear();
            Rows.Add(new Row());
        }

        public bool Check()
        {
            var userRow = Rows.Last();
            var userColors = userRow.Colors;
            var computerColors = ComputerChoice.Colors;

            userRow.IsChecked = true;
            userRow.Goods = computerColors.Where((item, index) => userColors[index] == item).Count();
            userRow.Bads  = computerColors.Where((item, index) => userColors.Contains(item)).Count() - userRow.Goods;

            if (userRow.Goods == userColors.Length)
            {
                return true;
            }
            else
            {
                Rows.Add(new Row());
                return false;
            }
        }
    }
}
