using System;
using Microsoft.AspNetCore.Blazor.Components;

namespace Blazor.Mastermind.Pages
{
    public class WinnerModel : BlazorComponent
    {
    }
}